/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.udec;

import javax.swing.JOptionPane;

/**
 *
 * @author sergio
 */
public class Principal {
    public static void main(String[] args) {
       Registro_ m1= new Registro_();
        m1.setVisible(true);
       
        
    }
}
